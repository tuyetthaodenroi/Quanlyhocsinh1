<?php 
    include $_SERVER['DOCUMENT_ROOT'].'/'.$domain.'/views/pages/auths/login.php';
?>