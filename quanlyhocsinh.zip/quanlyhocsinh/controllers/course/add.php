<?php 
    include $_SERVER['DOCUMENT_ROOT'].'/'.$domain.'/views/pages/course/add.php';
?>