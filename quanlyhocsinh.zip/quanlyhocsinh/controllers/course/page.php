<?php 
    require_once('././views/pages/course/page.php');
?>