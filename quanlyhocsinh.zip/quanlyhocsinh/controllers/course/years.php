<?php 
    require_once('././views/pages/course/years.php');
?>