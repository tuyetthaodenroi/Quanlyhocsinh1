<?php 
    require_once('././views/pages/department/edit.php');
?>