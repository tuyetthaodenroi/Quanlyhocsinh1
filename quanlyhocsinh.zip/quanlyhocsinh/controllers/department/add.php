<?php 
    require_once('././views/pages/department/add.php');
?>