<?php 
    require_once('././views/pages/department/delete.php');
?>