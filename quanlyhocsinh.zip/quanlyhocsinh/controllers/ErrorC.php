<?php 
    require_once('./views/pages/error.php');
?>