<?php
ob_start();
 $host = "localhost";
 $username = "root";
 $password = "";
 $database = "quanlyhocsinh";
 $conn = mysqli_connect($host,$username,$password,$database);
	include "Classes/PHPExcel.php";

	if(isset($_POST['btnExport'])){
		$objExcel = new PHPExcel;
		$objExcel->setActiveSheetIndex(0);
		$sheet = $objExcel ->getActiveSheet()->setTitle('2011');
		$rowCount = 1;
		$sheet->setCellValue('A'.$rowCount, 'MHS');
		$sheet->setCellValue('B'.$rowCount, 'Mật khẩu');
		$sheet->setCellValue('C'.$rowCount, 'Họ tên');
		$sheet->setCellValue('D'.$rowCount, 'Sinh nhật');
		$sheet->setCellValue('E'.$rowCount, 'Lớp');
		$sheet->setCellValue('F'.$rowCount, 'Tôn giáo');
		$sheet->setCellValue('G'.$rowCount, 'Dân tộc');
		$sheet->setCellValue('H'.$rowCount, 'Địa chỉ');
		$sheet->setCellValue('I'.$rowCount, 'Email');
		$sheet->setCellValue('J'.$rowCount, 'SĐT');
		$sheet->setCellValue('K'.$rowCount, 'Mô tả');
		$sheet->setCellValue('L'.$rowCount, 'Giới tính');
		$sheet->setCellValue('M'.$rowCount, 'Khóa học');
		
		$sql = "SELECT * FROM students";
		$result = mysqli_query($conn,$sql);
	
        
      


		while($row = mysqli_fetch_array($result)){

			$rowCount++;
			$sheet->setCellValue('A'.$rowCount, $row['student_code']);
			$sheet->setCellValue('B'.$rowCount, $row['student_password']);
			$sheet->setCellValue('C'.$rowCount, $row['student_fullname']);
			$sheet->setCellValue('D'.$rowCount, $row['student_birthday']);
			$sheet->setCellValue('E'.$rowCount, $row['student_class']);
			$sheet->setCellValue('F'.$rowCount, $row['nation']);
			$sheet->setCellValue('G'.$rowCount, $row['religion']);
			$sheet->setCellValue('H'.$rowCount, $row['student_address']);
			$sheet->setCellValue('I'.$rowCount, $row['student_email']);
			$sheet->setCellValue('J'.$rowCount, $row['student_phone']);
			$sheet->setCellValue('K'.$rowCount, $row['student_description']);
			$sheet->setCellValue('L'.$rowCount, $row['student_gender']);
			$sheet->setCellValue('M'.$rowCount,  $row['course']);

		}

		$objWriter = new PHPExcel_Writer_Excel2007($objExcel);
		$filename = 'thongtinhocsinh.xlsx';
		$objWriter->save($filename);
	
		header('Content-Disposition: attachment; filename="' . $filename . '"');
		header('Content-Type: application/vnd.openxmlformatsofficedocument.spreadsheetml.sheet');
		header('Content-Length:'. filesize($filename));
		header('Content-Transfer-Encoding: binary');
		header('Cache-Control: must-revalidate');
		header('Pragma:no-cache');
		readfile($filename);
		return;		
	}
?>
<?php
if(isset($_POST['btnImport'])){
	




// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['btnImport'])) {


	include $_SERVER['DOCUMENT_ROOT'].'/'.$domain.'/models/StudentM.php';
	// Check if file was uploaded without errors
	if (isset($_FILES["excel"]) && $_FILES["excel"]["error"] == 0) {
	$target_dir = "public/";
	$target_file = $target_dir . basename($_FILES["excel"]["name"]);
	
	$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
	
   



	// Move the uploaded file to a permanent location
	if (move_uploaded_file($_FILES["excel"]["tmp_name"], $target_file)) {
	  
	} else {
		echo "Sorry, there was an error uploading your file.";
	}
} else {
	echo "No image was selected to upload.";
	}
}






	include 'Classes/PHPExcel/IOFactory.php';
	if(file_exists('C:\xampp\htdocs\quanlyhocsinh\public\thongtinhocsinh.xlsx')){
		$inputFileName = 'C:\xampp\htdocs\quanlyhocsinh\public\thongtinhocsinh.xlsx';

	//  Tiến hành đọc file excel
	try {
		$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
		$objReader = PHPExcel_IOFactory::createReader($inputFileType);
		$objPHPExcel = $objReader->load($inputFileName);
	} catch(Exception $e) {
		die('Lỗi không thể đọc file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
	}
	
	//  Lấy thông tin cơ bản của file excel
	
	// Lấy sheet hiện tại
	$sheet = $objPHPExcel->getSheet(0); 
	
	// Lấy tổng số dòng của file, trong trường hợp này là 6 dòng
	$highestRow = $sheet->getHighestRow(); 
	
	// Lấy tổng số cột của file, trong trường hợp này là 4 dòng
	$highestColumn = $sheet->getHighestColumn();
	
	// Khai báo mảng $rowData chứa dữ liệu
	
	//  Thực hiện việc lặp qua từng dòng của file, để lấy thông tin
	for ($row = 1; $row <= $highestRow; $row++){ 
		// Lấy dữ liệu từng dòng và đưa vào mảng $rowData
		$rowData[] = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, NULL, TRUE,FALSE);
	}
	
	//In dữ liệu của mảng
	echo "<pre>";
	$thatbai = 0;
	$thanhcong = 0;

	$result = array_merge($rowData);   
	foreach($result as $datas){
		if($result[0]===$datas){
		
		}
		else{
	
		?>
				<?php
			
		
						foreach($datas as $dt){
					
							$code = $dt[0];
							$fullname = $dt[2];
							$password = $dt[1];
							$gender = $dt[11];
							$birthday = $dt[3];
					
						
							$nation = $dt[5];
							$religion =$dt[6];
							
						
							$class = $dt[4];
							$course =  $dt[12];
							
							$address = $dt[7];
							$email = $dt[8];
							$phone = $dt[9];
							$images =  'image.jpg';
							$description =   $dt[10];
							$data = [
								"student_code" => "$code",
								"student_password" => "$password", 
								"student_birthday" => "$birthday", 
								"student_address" => "$address",
								"student_fullname" => "$fullname",
					
								"religion" => "$religion",
								"nation" => "$nation",
						
								"student_created" => "22/07/1999",
								"student_ip" => 123,
								"is_public" => 1,
								"student_gender" => "$gender",
					
								"student_class" => "$class",
								"course" => "$course",
					
								"student_email" => "$email",
								"student_phone" => "$phone",
								"student_image" => "$images",
								"student_description" => "$description",
							];
						
							$studentM = new StudentM();
							$chekStudentAvailable =  $studentM->getOneStudent("student_code = '$code'");
					
							if($chekStudentAvailable==NULL){
								$studentM-> addOneStudent($data);
								
								$thanhcong=$thanhcong+1;
								
							}
							else {
								$thatbai=$thatbai+1;
							
							}
				}
		
					
					
						?>
					
		<?php
		
		}
		
	
		

	}
	if($thanhcong===0 && $thatbai==0){
		echo "<script>alert('Nhập không thành công. File không có dữ liệu.')</script>";
		echo "<script>location.href='students/page/1';</script>";
	}
	else{
		echo '<script>alert("Số lượng nhập vào thành công: '.$thanhcong.
		' Số lượng nhập vào thất bại: '.$thatbai.'")</script>';
echo "<script>location.href='students/page/1';</script>";	
unlink('C:\xampp\htdocs\quanlyhocsinh\public\thongtinhocsinh.xlsx');
}

	
}
else{
	echo "<script>alert('Không thành công. Vui lòng nhập file exel có tên là thongtinhocsinh.xlsx.')</script>";
	echo "<script>location.href='students/page/1';</script>";
	}

	
}
?>




