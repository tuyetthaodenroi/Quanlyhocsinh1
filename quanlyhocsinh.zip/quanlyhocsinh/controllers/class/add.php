<?php 
    include $_SERVER['DOCUMENT_ROOT'].'/'.$domain.'/views/pages/class/add.php';
?>