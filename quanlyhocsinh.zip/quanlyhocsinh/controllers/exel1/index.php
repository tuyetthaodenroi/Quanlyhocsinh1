<?php
ob_start();
 $host = "localhost";
 $username = "root";
 $password = "";
 $database = "quanlyhocsinh";
 $conn = mysqli_connect($host,$username,$password,$database);
	include "Classes/PHPExcel.php";

	if(isset($_POST['btnExport'])){
		$objExcel = new PHPExcel;
		$objExcel->setActiveSheetIndex(0);
		$sheet = $objExcel ->getActiveSheet()->setTitle('2011');
		$rowCount = 1;
		$sheet->setCellValue('A'.$rowCount, 'STT');
		$sheet->setCellValue('B'.$rowCount, 'Tên môn học');
		$sheet->setCellValue('C'.$rowCount, 'Năm học');
		$sheet->setCellValue('D'.$rowCount, 'Học kỳ');
		$sheet->setCellValue('E'.$rowCount, 'Lớp');
		$sheet->setCellValue('F'.$rowCount, 'MHS');
		$sheet->setCellValue('G'.$rowCount, 'Tên học sinh');
		$sheet->setCellValue('H'.$rowCount, 'Đánh giá thường xuyên');
		$sheet->setCellValue('I'.$rowCount, 'Đánh giá giữa kỳ');
		$sheet->setCellValue('J'.$rowCount, 'Đánh giá cuối kỳ');
		$sheet->setCellValue('L'.$rowCount, 'Điểm TB');
		// $sheet->setCellValue('K'.$rowCount, 'Đánh giá');
		$sheet->setCellValue('M'.$rowCount, 'Thời gian nhập');
		$sheet->setCellValue('N'.$rowCount, 'Người nhập');
		
		$sql = "SELECT * FROM points";
		$result = mysqli_query($conn,$sql);
	
        
      


		while($row = mysqli_fetch_array($result)){

			$rowCount++;
			$sheet->setCellValue('A'.$rowCount, $row['point_id']);
			$sheet->setCellValue('B'.$rowCount, $row['module_name']);
			$sheet->setCellValue('C'.$rowCount, $row['course']);
			$sheet->setCellValue('D'.$rowCount, $row['hk']);
			$sheet->setCellValue('E'.$rowCount, $row['class']);
			$sheet->setCellValue('F'.$rowCount, $row['student_code']);
			$sheet->setCellValue('G'.$rowCount, $row['student_name']);
			$sheet->setCellValue('H'.$rowCount, $row['point_1']);
			$sheet->setCellValue('I'.$rowCount, $row['point_3']);
			$sheet->setCellValue('J'.$rowCount, $row['point_4']);
		
			$sheet->setCellValue('L'.$rowCount, round($row['pont_gpa_10']),1);
			$sheet->setCellValue('M'.$rowCount, $row['time_type']);
			$sheet->setCellValue('N'.$rowCount, $row['who_type']);
	


		}

		$objWriter = new PHPExcel_Writer_Excel2007($objExcel);
		$filename = 'diemhocsinh.xlsx';
		$objWriter->save($filename);
	
		header('Content-Disposition: attachment; filename="' . $filename . '"');
		header('Content-Type: application/vnd.openxmlformatsofficedocument.spreadsheetml.sheet');
		header('Content-Length:'. filesize($filename));
		header('Content-Transfer-Encoding: binary');
		header('Cache-Control: must-revalidate');
		header('Pragma:no-cache');
		readfile($filename);
		return;		
	}
?>
<?php
if(isset($_POST['btnImport'])){
	




// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['btnImport'])) {


	include $_SERVER['DOCUMENT_ROOT'].'/'.$domain.'/models/PointM.php';
	// Check if file was uploaded without errors
	if (isset($_FILES["excel"]) && $_FILES["excel"]["error"] == 0) {
	$target_dir = "public/";
	$target_file = $target_dir . basename($_FILES["excel"]["name"]);
	
	$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
	echo $_FILES["excel"]["name"];
   



	// Move the uploaded file to a permanent location
	if (move_uploaded_file($_FILES["excel"]["tmp_name"], $target_file)) {
	  
	} else {
		echo "Sorry, there was an error uploading your file.";
	}
} else {
	echo "No image was selected to upload.";
	}
}






	include 'Classes/PHPExcel/IOFactory.php';

	$inputFileName = 'C:\xampp\htdocs\quanlyhocsinh\public\diemhocsinh.xlsx';

	//  Tiến hành đọc file excel
	try {
		$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
		$objReader = PHPExcel_IOFactory::createReader($inputFileType);
		$objPHPExcel = $objReader->load($inputFileName);
	} catch(Exception $e) {
		die('Lỗi không thể đọc file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
	}
	
	//  Lấy thông tin cơ bản của file excel
	
	// Lấy sheet hiện tại
	$sheet = $objPHPExcel->getSheet(0); 
	
	// Lấy tổng số dòng của file, trong trường hợp này là 6 dòng
	$highestRow = $sheet->getHighestRow(); 
	
	// Lấy tổng số cột của file, trong trường hợp này là 4 dòng
	$highestColumn = $sheet->getHighestColumn();
	
	// Khai báo mảng $rowData chứa dữ liệu
	
	//  Thực hiện việc lặp qua từng dòng của file, để lấy thông tin
	for ($row = 1; $row <= $highestRow; $row++){ 
		// Lấy dữ liệu từng dòng và đưa vào mảng $rowData
		$rowData[] = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, NULL, TRUE,FALSE);
	}
	
	//In dữ liệu của mảng
	echo "<pre>";
	$thatbai = 0;
	$thanhcong = 0;

	$result = array_merge($rowData);   
	foreach($result as $datas){
		if($result[0]===$datas){
		
		}
		else{
	
		?>
		
				<?php
		
			
		
						foreach($datas as $dt){
					
							$a_0 = $dt[1];
							$a_1 = $dt[2];
							$a_2 = $dt[3];
							$a_3 = $dt[4];
							$a_4 = $dt[5];
					
						
							$a_5 = $dt[6];
							$a_6 =$dt[7];
							
						
							$a_7 = $dt[8];
							$a_8 =  $dt[9];
							
							$a_9 = $dt[10];
							$a_10 = $dt[11];
							$a_11 = $dt[12];
						
							$time = date("m/d/Y h:i:s a", time());
							if($a_0=="Giáo dục thể chất" || $a_0 =="Nội dung giáo dục của địa phương"||$a_0=="Hoạt động trải nghiệm, hướng nghiệp"){
								if($a_8!="Đạt"){
									$kq = "Chưa đạt";
								}
								else if($a_6!="Đạt" && $a_7!="Đạt"){
									$kq ="Chưa đạt";
								}
								else if($a_6=="Chưa đạt"|| $a_7=="Chưa đạt"||$a_8=="Chưa đạt"){
									$kq ="Chưa đạt";
								}
								else if($a_6==""||$a_7==""||$a_8==""){
									$kq ="Chưa đạt";
								}
								else{
									$kq ="Đạt";
								}
								
							}
							
							else{
								

								$kq = round(($a_6+$a_7*2+$a_8*3)/6,1);
							
							}
							$data = [

								"module_name" => "$a_0",
								
								"course" => "$a_1",
								"hk" => "$a_2",
								"class" => "$a_3",
							
								"student_code" => "$a_4",
								"student_name" => "$a_5",
								"point_1" => "$a_6", 
								"point_3" => "$a_7",
								"point_4"=>"$a_8",
								
								"pont_gpa_10"=>$kq,
								"who_type"=>"Đỗ Tuyết Thảo"
								
							];
						
							$studentM = new PointM();
							$chekStudentAvailable =  $studentM->getOnePoint("point_id = '$a_0'");
					
							if($chekStudentAvailable==NULL){
								$studentM-> addOnePoint($data);
								
								$thanhcong=$thanhcong+1;
								
							}
							else {
								$thatbai=$thatbai+1;
							
							}
				}
						

					
					
						?>
					
		<?php
		
		}
	
		

	}
	echo '<script>alert("Số lượng điểm nhập vào thành công: '.$thanhcong.
						' Số lượng điểm nhập vào thất bại: '.$thatbai.'")</script>';
	echo "<script>location.href='points/page/1';</script>";	
	unlink('C:\xampp\htdocs\quanlyhocsinh\public\diemhocsinh.xlsx');
}
?>



